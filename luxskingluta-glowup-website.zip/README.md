# Luxskingluta GLOWUP — Website

Website statis untuk GitHub Pages. Tidak membutuhkan build tools.

## File
- `index.html` — konten dan struktur semua bagian.
- `style.css` — desain responsif dan animasi.
- `script.js` — pencarian, filter kategori, menu HP, dan order WhatsApp.
- `assets/products/` — tempat menyimpan foto produk asli.

## Cara melihat
Buka `index.html` di browser atau unggah semua file ke repository GitHub.

## Cara mengubah foto produk
Saat ini gambar katalog berbentuk ilustrasi botol CSS sebagai placeholder. Untuk memakai foto asli:
1. Letakkan foto di `assets/products/`, misalnya `luxskingluta.jpg`.
2. Buka `index.html`.
3. Pada setiap kartu produk, cari elemen `<div class="product-image ...">` dan ganti area ilustrasi botol dengan:
   `<img class="real-product-image" src="assets/products/luxskingluta.jpg" alt="Produk Luxskingluta">`
4. Tambahkan aturan CSS:
   `.real-product-image{width:100%;height:100%;object-fit:contain;padding:25px}`

## Cara mengubah harga dan deskripsi
Edit teks `Tanya harga` dan deskripsi pada masing-masing kartu di `index.html`. Jangan lupa cek ulang informasi, komposisi, aturan pakai, nomor BPOM/halal, dan klaim sebelum dipublikasikan.

## Cara mengubah FAQ
Bagian FAQ berada di `index.html` pada `<section id="faq">`. Setiap pertanyaan ada dalam elemen `<details class="faq-item">`. Duplikasi satu elemen tersebut untuk menambah pertanyaan baru.

## WhatsApp
Nomor admin disimpan di bagian atas `script.js` sebagai `WHATSAPP_NUMBER`. Format internasional tanpa `+`, spasi, atau tanda hubung.

## Deploy ke GitHub Pages
1. Buat repository GitHub baru.
2. Unggah `index.html`, `style.css`, `script.js`, dan folder `assets`.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/(root)`, lalu **Save**.
6. Tunggu proses deploy selesai dan buka URL Pages yang ditampilkan GitHub.

## Catatan penting
- FAQ keselamatan dan BPOM/halal dibuat dengan bahasa berhati-hati. Pastikan klaim sesuai dokumen resmi produk sebelum mengubahnya.
- Testimoni di website adalah template yang harus diganti dengan ulasan asli dan izin pelanggan.
- Harga, stok, aturan DP/cicilan, pengiriman, dan kebijakan komplain perlu diisi sesuai kebijakan toko.
